public class Shape{
    private String mColor;
    public Shape(String color){
        mColor = color;
    }
    public String getColor(){
        return mColor;
    }
    public double area(){
        double aValue;
        return 0.0;
    }
    public String toString(){
        String encodedLine;
        encodedLine = "generic shape";
        return encodedLine;
    }
}